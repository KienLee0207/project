$(document).ready(function(){
        // Phần header scroll
        window.onscroll = function() {myFunction()};

   function myFunction() {
 if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
    document.getElementById("nav").className = "fixed";
    $(".menu").css("display","none")
} else {
    document.getElementById("nav").className = "";
};
};
        $("#mega-menu").click(function(){
          $(".menu").toggle();
        });
        var modal = document.getElementById('modal');
        var btn = document.getElementById("btn-login");
        var span = document.getElementsByClassName("close")[0];
        var cancelbtn=document.getElementsByClassName("cancelbtn")[0];
        btn.onclick = function() {
          modal.style.display = "block";
        }
        span.onclick = function() {
          modal.style.display = "none";
        }
        cancelbtn.onclick= function(){
          modal.style.display="none";
        }
        window.onclick = function(event) {
          if (event.target == modal) {
            modal.style.display = "none";
          }
        }

        var modalProduct = document.getElementById("modalProduct");
        var zoomImg = document.getElementsByClassName("zoomImg")[0];
        var close= document.getElementsByClassName("close")[0];
        zoomImg.onclick=function(){
            modalProduct.style.display="block";
        }
        close.onclick=function(){
            modalProduct.style.display="none";
        }
        window.onclick = function(event){
          if(event.target =modalProduct){
            modalProduct.style.display="none";
          }
        }
});
        $(".btn-success").click(function(){
          $("#modal-add-cart").css("display","block")
        });
        $(document).ready(function ($) {
        if ($(window).scrollTop() > 200) {
                    $('.scrollTop').fadeIn();
              } else {
                    $('.scrollTop').fadeOut();
              }

        $(window).scroll(function () {
                if ($(this).scrollTop() > 200) {
            $('.scrollTop').fadeIn();
                } else {
                      $('.scrollTop').fadeOut();
                }
        });

        $('.scrollTop').click(function () {
                $("html, body").animate({
                      scrollTop: 0
                }, 600);
                return false;
        });

      });
          $(".btn-success").click(function(){
            setTimeout(function(){
              $("#modal-add-cart").fadeOut();
            },2000);
            
              setTimeout(function(){
                var cart = $(document).find(".login");
                var citem = parseInt(cart.find("#count-item").data("count"))+1;
              cart.find("#count-item").text(citem).data("count",citem);
            },500);
          });
          var kiemtraDT= isNaN(PHONE);
            function checkinput(url){
              
              if(document.flogin.USERNAME.value==""){
                alert("Please enter your Name:");
                document.flogin.USERNAME.focus();
                return false;
              };
              if(document.flogin.EMAIL.value==""){
                alert("Please enter your Email address");
                document.flogin.EMAIL.focus();
                return false;
              };
              if(document.flogin.COMMENT.value=""){
                alert("Please enter your Comment:");
                return false;
              }
              if(document.flogin.PHONE.value==false){
                alert("Please enter your phone number");
                document.flogin.PHONE.focus();
                return false;
              };
              if(kiemtraDT=false){
                alert("The phone must be in digital format");
                return false;
              };
              if(flogin=true){
                alert('Success !!');
              };
            };

            